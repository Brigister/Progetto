const express = require("express");
const router = express.Router();
const mongoose = require("mongoose");
const checkAuth = require('../check-auth');

const Conversation = require('./models/conversation');
const User = require('./models/user');

router.post("/", checkAuth, (req, res, next) => {
    User.findOne({ username: req.body.receiver })
        .then(user => {
            if (!user) {
                return res.status(404).json({
                    message: "User not found"
                });
            }
            const conversation = new Conversation({
                _id: mongoose.Types.ObjectId(),
                creator: req.body.creator,
                receiver: req.body.receiver,
            })
            return conversation.save()
        })
        .then(result => {
            console.log(result);
            res.status(201).json({
                message: "conversation created",
            });
        })
        .catch(err => {
            console.log(err);
            res.status(500).json({
                error: err
            });
        });
})

module.exports = router;