const mongoose = require('mongoose');

const chatSchema = mongoose.Schema({
    _id: mongoose.Schema.Types.ObjectId,
    payload: { type: String, required: true },
    date: { type: String, required: true },

})

const conversationSchema = mongoose.Schema({
    _id: mongoose.Schema.Types.ObjectId,
    creator: { type: String, required: true },
    receiver: { type: String, required: true },
    message: [chatSchema]
})

module.exports = mongoose.model('Conversation', conversationSchema);