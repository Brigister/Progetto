const express = require("express");
const router = express.Router();
const mongoose = require("mongoose");
const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");
const checkAuth = require('../check-auth');

const User = require("./models/user");

router.post("/signup", (req, res, next) => {
    User.find({ email: req.body.email })
        .exec()
        .then(user => {
            if (user.length >= 1) {
                return res.status(409).json({
                    message: "Mail exists"
                });
            } else {
                bcrypt.hash(req.body.password, 10, (err, hash) => {
                    if (err) {
                        return res.status(500).json({
                            error: err
                        });
                    } else {
                        const user = new User({
                            _id: new mongoose.Types.ObjectId(),
                            email: req.body.email,
                            password: hash,
                            username: req.body.username
                        });
                        user
                            .save()
                            .then(result => {
                                console.log(result);
                                res.status(201).json({
                                    message: "User created"
                                });
                            })
                            .catch(err => {
                                console.log(err);
                                res.status(500).json({
                                    error: err
                                });
                            });
                    }
                });
            }
        });
});

router.post("/login", (req, res, next) => {
    User.find({ email: req.body.email })
        .exec()
        .then(user => {
            if (user.length < 1) {
                return res.status(401).json({
                    message: "Auth failed"
                });
            }
            bcrypt.compare(req.body.password, user[0].password, (err, result) => {
                if (err) {
                    return res.status(401).json({
                        message: "Auth failed"
                    });
                }
                if (result) {
                    const token = jwt.sign({
                            email: user[0].email,
                            username: user[0].username,
                            userId: user[0]._id,
                            isAdmin: user[0].isAdmin,

                        },
                        'passwordsegreta', {
                            expiresIn: "1h"
                        }
                    );
                    return res.status(200).json({
                        message: "Auth successful",
                        token: token
                    });
                }
                res.status(401).json({
                    message: "Auth failed"
                });
            });
        })
        .catch(err => {
            console.log(err);
            res.status(500).json({
                error: err
            });
        });
});

router.get("/", checkAuth, (req, res, next) => {
    User.find()
        .select('email _id username win losses isAdmin')
        .sort({ win: 'descending' })
        .exec()
        .then(user => {
            if (!user) {
                return res.status(404).json({
                    message: "User not found"
                });
            }
            res.status(200).json({
                user: user
            });
        })
        .catch(err => {
            res.status(500).json({
                error: err
            });
        });
});

router.get("/:username/check", checkAuth, (req, res, next) => {
    const username = req.params.username;
    User.findOne({ username: username })
        .select('_id')
        .exec()
        .then(user => {
            if (!user) {
                return res.send(false);
            }
            res.status(200).send(true);
        })
        .catch(err => {
            res.status(500).json({
                error: err
            });
        });
});

router.delete("/:userId", checkAuth, (req, res, next) => {
    User.remove({ _id: req.params.userId })
        .exec()
        .then(result => {
            res.status(200).json({
                message: "User deleted"
            });
        })
        .catch(err => {
            console.log(err);
            res.status(500).json({
                error: err
            });
        });
});

//ritorna lo status di admin
router.get("/:userId", checkAuth, (req, res) => {
    const id = req.params.userId;
    User.findOne({ _id: id })
        .select('isAdmin')
        .exec()
        .then(user => {
            if (!user) {
                return res.status(404).json({
                    message: "user not found"
                });
            }
            res.status(200).json({
                user: user,
                message: "user found, returning admin status",
            });
        })
        .catch(err => {
            res.status(500).json({
                error: err
            });
        });
});

router.get("/:username/statistics", checkAuth, (req, res, next) => {
    const username = req.params.username;
    User.findOne({ username: username })
        .select('username win losses')
        .exec()
        .then(user => {
            if (!user) {
                return res.status(404).json({
                    message: "user not found"
                });
            }
            res.status(200).json({
                user: user,
                message: "user found, returning user statistics",
            });
        })
        .catch(err => {
            res.status(500).json({
                error: err
            });
        });
});

router.patch("/:username/win", checkAuth, (req, res) => {
    const username = req.params.username;
    User.findOneAndUpdate({ username: username }, { $inc: { win: 1 } })
        .exec()
        .then(result => {
            res.status(200).json({
                message: 'wins updated'
            });
        })
        .catch(err => {
            console.log(err);
            res.status(500).json({
                error: err
            });
        });
});

router.patch("/:username/loss", checkAuth, (req, res) => {
    const username = req.params.username;
    User.findOneAndUpdate({ username: username }, { $inc: { losses: 1 } })
        .exec()
        .then(result => {
            res.status(200).json({
                message: 'losses updated'
            });
        })
        .catch(err => {
            console.log(err);
            res.status(500).json({
                error: err
            });
        });
});

router.patch("/:username/upgrade", checkAuth, (req, res) => {
    const username = req.params.username;
    User.findOneAndUpdate({ username: username }, { isAdmin: true })
        .exec()
        .then(result => {
            res.status(200).json({
                message: 'user upgraded to admin'
            });
        })
        .catch(err => {
            console.log(err);
            res.status(500).json({
                error: err
            });
        });
})

router.patch("/:username/downgrade", checkAuth, (req, res) => {
    const username = req.params.username;
    User.findOneAndUpdate({ username: username }, { isAdmin: false })
        .exec()
        .then(result => {
            res.status(200).json({
                message: 'admin downgraded to user'
            });
        })
        .catch(err => {
            console.log(err);
            res.status(500).json({
                error: err
            });
        });
})

module.exports = router;