const express = require("express");
const router = express.Router();
const mongoose = require("mongoose");
const checkAuth = require('../check-auth');

const Message = require("./models/message");
const User = require("./models/user");

router.get("/:username", checkAuth, (req, res, next) => {
    Message.find({ recipient: req.params.username })
        .select('content author date')
        .exec()
        .then(message => {
            if (!message) {
                return res.status(404).json({
                    message: "messages not found"
                });
            }
            res.status(200).json({
                message: message
            });
        })
        .catch(err => {
            res.status(500).json({
                error: err
            });
        });
});

router.get("/:username/sent", checkAuth, (req, res, next) => {
    Message.find({ author: req.params.username })
        .select('content recipient date')
        .exec()
        .then(message => {
            if (!message) {
                return res.status(404).json({
                    message: "messages not found"
                });
            }
            res.status(200).json({
                message: message
            });
        })
        .catch(err => {
            res.status(500).json({
                error: err
            });
        });
});


router.post("/", checkAuth, (req, res, next) => {
    User.find({ username: req.body.recipient })
        .then(user => {
            if (!user) {
                return res.status(404).json({
                    message: "User not found"
                });
            }
            const message = new Message({
                _id: mongoose.Types.ObjectId(),
                author: req.body.author,
                recipient: req.body.recipient,
                content: req.body.content,
                date: req.body.date
            });
            return message.save();
        })
        .then(result => {
            console.log(result);
            res.status(201).json({
                message: "message sended",
            });
        })
        .catch(err => {
            console.log(err);
            res.status(500).json({
                error: err
            });
        });
});

router.delete("/:messageId", checkAuth, (req, res, next) => {
    Message.remove({ _id: req.params.messageId })
        .exec()
        .then(result => {
            res.status(200).json({
                message: "Message deleted"
            });
        })
        .catch(err => {
            console.log(err);
            res.status(500).json({
                error: err
            });
        });
});


module.exports = router;