const http = require('http');
const express = require('express');
const app = express();
const bodyParser = require("body-parser");
const mongoose = require('mongoose');
const cors = require('cors');
const io = require('socket.io');

//importazione Routes
const messageRoutes = require('./api/routes/messages');
const userRoutes = require('./api/routes/user');
const conversationRoutes = require('./api/routes/conversations');


const port = process.env.PORT || 3000;

const server = http.createServer(app);

//connessione al db
mongoose.connect('mongodb+srv://Byteman:Admin@naval-battle-rft6u.mongodb.net/test?retryWrites=true', { useNewUrlParser: true });

//Body Parser
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

// Allow-Access-Controll-Header -> Cors Errors
app.use(cors({ origin: '*' }));

//uso Routes
app.use("/messages", messageRoutes);
app.use("/user", userRoutes);
app.use("/conversation", conversationRoutes);

//serve solo per le win
app.use((req, res, next) => {
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Headers', 'X-Requested-With,content-type');
    res.setHeader('Access-Control-Allow-Method', 'GET, PUT, POST, PATCH, DELETE');

    if (req.method === 'OPTIONS') {
        res.setHeader('Access-Control-Allow-Method', 'GET, PUT, POST, PATCH, DELETE')
        return res.status(200).json({});
    }
    next();
});

//Error Handling
app.use((req, res, next) => {
    const error = new Error("Not found");
    error.status = 404;
    next(error);
});

app.use((error, req, res, next) => {
    res.status(error.status || 500);
    res.json({
        error: {
            message: error.message
        }
    });
});


//socket.io
const ios = io(server);

var gameId;

var queue = null;
ios.on('connection', (socket) => {
    console.log('nuovo utente connesso')

    if (queue == null) {
        console.log('Creazione nuova partita...');
        gameId = Math.random().toString(36).substr(2, 8);
        queue = socket;
        queue.join('' + gameId);
        queue.emit('create lobby', gameId);

    } else {
        console.log('Partita trovata');
        socket.join('' + gameId);
        socket.emit('entering lobby', gameId);

    }

    socket.on('on start', function(data) {
        socket.emit('on game start', "1");
        queue.emit('on game start', "2");
        queue = null;
    })

    socket.on('submit board', function(data) {
        console.log(data);
        socket.to('' + gameId).broadcast.emit('receive board', data);
    });

    socket.on('click tile', function(newTurn) {
        newTurn = "1" ? "2" : "1"
        console.log(newTurn);
        socket.to('' + gameId).broadcast.emit('change turn', newTurn);
    })

    socket.on('on fire', function(data) {
        console.log(data);
        socket.to('' + gameId).broadcast.emit('fire in the hole', data);
    });

    socket.on('on victory', function(data) {
        console.log(data + ' vince');
        socket.to('' + gameId).broadcast.emit('on loss', data);
    })

    socket.on('on leaving', function() {
        socket.to('' + gameId).broadcast.emit('win by quit');
    })

    socket.on('on leaving queue', function() {
        socket.leave('' + gameId);
        queue = null;
    })


})

/* ios.on('disconnect', function() {
    console.log('utente disconnesso')
}) */


server.listen(port);